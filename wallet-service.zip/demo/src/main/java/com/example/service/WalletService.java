package com.example.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dto.TransactionRequest;
import com.example.entity.EntryType;
import com.example.entity.LedgerEntry;
import com.example.entity.Transaction;
import com.example.entity.TransactionType;
import com.example.entity.User;
import com.example.entity.Wallet;
import com.example.repository.*;

import java.math.BigDecimal;
import java.util.*;

@Service
@RequiredArgsConstructor
public class WalletService {

    private final WalletRepository walletRepository;
    private final TransactionRepository transactionRepository;
    private final LedgerEntryRepository ledgerRepository;
    private final UserRepository userRepository;
    
    public WalletService(
            WalletRepository walletRepository,
            TransactionRepository transactionRepository,
            LedgerEntryRepository ledgerRepository,
            UserRepository userRepository) {

        this.walletRepository = walletRepository;
        this.transactionRepository = transactionRepository;
        this.ledgerRepository = ledgerRepository;
        this.userRepository = userRepository;
    }

    private static final String TREASURY_USERNAME = "SYSTEM_TREASURY";

    @Transactional
    public void processTransaction(TransactionRequest request,
                                   TransactionType type) {

        // Idempotency check
        if (transactionRepository.findByIdempotencyKey(
                request.getIdempotencyKey()).isPresent()) {
            return;
        }

        Wallet userWallet = walletRepository
                .findByUserIdAndAssetTypeId(
                        request.getUserId(),
                        request.getAssetTypeId())
                .orElseThrow();

        User treasuryUser = userRepository.findAll()
                .stream()
                .filter(u -> u.getUsername()
                        .equals(TREASURY_USERNAME))
                .findFirst()
                .orElseThrow();

        Wallet treasuryWallet = walletRepository
                .findByUserIdAndAssetTypeId(
                        treasuryUser.getId(),
                        request.getAssetTypeId())
                .orElseThrow();

        // Deterministic locking
        List<Wallet> wallets = List.of(userWallet, treasuryWallet);
        wallets.stream()
                .sorted(Comparator.comparing(Wallet::getId))
                .forEach(w ->
                        walletRepository.findByIdForUpdate(w.getId()));

        BigDecimal balance =
                ledgerRepository.calculateBalance(userWallet.getId());

        if (type == TransactionType.SPEND &&
                balance.compareTo(request.getAmount()) < 0) {
            throw new RuntimeException("Insufficient balance");
        }

        Transaction tx = new Transaction();
        tx.setIdempotencyKey(request.getIdempotencyKey());
        tx.setType(type);
        tx.setStatus("COMPLETED");
        transactionRepository.save(tx);

        createDoubleEntry(tx, userWallet,
                treasuryWallet,
                request.getAmount(),
                type);
    }

    private void createDoubleEntry(Transaction tx,
                                   Wallet userWallet,
                                   Wallet treasuryWallet,
                                   BigDecimal amount,
                                   TransactionType type) {

        if (type == TransactionType.SPEND) {

            ledgerRepository.save(createEntry(tx, userWallet,
                    amount, EntryType.DEBIT));

            ledgerRepository.save(createEntry(tx, treasuryWallet,
                    amount, EntryType.CREDIT));

        } else {

            ledgerRepository.save(createEntry(tx, treasuryWallet,
                    amount, EntryType.DEBIT));

            ledgerRepository.save(createEntry(tx, userWallet,
                    amount, EntryType.CREDIT));
        }
    }

    private LedgerEntry createEntry(Transaction tx,
                                    Wallet wallet,
                                    BigDecimal amount,
                                    EntryType type) {
        LedgerEntry entry = new LedgerEntry();
        entry.setTransaction(tx);
        entry.setWallet(wallet);
        entry.setAmount(amount);
        entry.setEntryType(type);
        return entry;
    }

    public BigDecimal getBalance(Long userId, Long assetId) {
        Wallet wallet = walletRepository
                .findByUserIdAndAssetTypeId(userId, assetId)
                .orElseThrow();

        return ledgerRepository.calculateBalance(wallet.getId());
    }
}
