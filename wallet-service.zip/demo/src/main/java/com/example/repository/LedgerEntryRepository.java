package com.example.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.entity.LedgerEntry;

public interface LedgerEntryRepository extends JpaRepository<LedgerEntry, Long> {

    @Query("""
        SELECT COALESCE(SUM(
            CASE WHEN l.entryType = 'CREDIT'
                 THEN l.amount
                 ELSE -l.amount
            END), 0)
        FROM LedgerEntry l
        WHERE l.wallet.id = :walletId
    """)
    BigDecimal calculateBalance(@Param("walletId") Long walletId);
}
