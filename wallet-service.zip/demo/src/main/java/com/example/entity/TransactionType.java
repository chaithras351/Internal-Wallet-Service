package com.example.entity;

public enum TransactionType {
    TOPUP,
    BONUS,
    SPEND
}
