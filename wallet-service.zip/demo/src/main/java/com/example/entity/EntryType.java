package com.example.entity;

public enum EntryType {
    DEBIT,
    CREDIT
}
