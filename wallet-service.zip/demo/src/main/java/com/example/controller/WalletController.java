package com.example.controller;

import com.example.dto.BalanceResponse;
import com.example.dto.TransactionRequest;
import com.example.entity.TransactionType;
import com.example.service.WalletService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/wallets")
public class WalletController {

    private final WalletService walletService;

    public WalletController(WalletService walletService) {
        this.walletService = walletService;
    }

    @PostMapping("/topup")
    public ResponseEntity<String> topup(
            @RequestBody TransactionRequest request) {

        walletService.processTransaction(request,
                TransactionType.TOPUP);

        return ResponseEntity.ok("Topup successful");
    }

    @PostMapping("/bonus")
    public ResponseEntity<String> bonus(
            @RequestBody TransactionRequest request) {

        walletService.processTransaction(request,
                TransactionType.BONUS);

        return ResponseEntity.ok("Bonus added");
    }

    @PostMapping("/spend")
    public ResponseEntity<String> spend(
            @RequestBody TransactionRequest request) {

        walletService.processTransaction(request,
                TransactionType.SPEND);

        return ResponseEntity.ok("Spend successful");
    }

    @GetMapping("/{userId}/{assetId}/balance")
    public BalanceResponse balance(
            @PathVariable Long userId,
            @PathVariable Long assetId) {

        return new BalanceResponse(
                walletService.getBalance(userId, assetId));
    }
}
