create database wallet_db;

USE wallet_db;

INSERT INTO asset_types (id, name) VALUES (1, 'Gold Coins');

INSERT INTO users (id, username) VALUES (1, 'bob');
INSERT INTO users (id, username) VALUES (2, 'alex');

INSERT INTO wallets (id, user_id, asset_type_id, version)
VALUES (1, 1, 1, 1000);

INSERT INTO wallets (id, user_id, asset_type_id, version)
VALUES (2, 2, 1, 500);